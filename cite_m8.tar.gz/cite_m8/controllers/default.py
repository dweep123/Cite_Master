# -*- coding: utf-8 -*-
### required - do no delete
def user(): return dict(form=auth())
#def download(): return response.download(request,db)
#def call(): return service()
### end requires
#def index():
 #   return dict()

#def error():
 #   return dict()
from gluon.tools import fetch
import re
listf=[]
#ret1=[]
count=0
bigans=[]
@auth.requires_login()
def index():
    form=SQLFORM(db.input)
    if form.process().accepted:
        response.flash = 'you entred'
        redirect(URL('final_ans'))
    return dict(form=form)
def year_user(index_yr):   #index_yr - only in this code not in main one
    flag=index_yr
    redirect(URL('final_ans()'))
    flag=0
    #return dict(ans=ll1[0],l_yr=ll1[1])
def extract1(url,l1):
    ret=[]
    ret1=[]
    html=fetch(url)
    html_splitted=html.split("<A HREF=\"citation.cfm")
    ht=html_splitted[0]
    del html_splitted[0]
    k=html_splitted[0].split('>')
    if k[1][:-3]==l1[0]:
        k=html_splitted[0].find('\"')
        s="http://dl.acm.org/citation.cfm"+html_splitted[0][:k]
        ret.append(s.split('&preflayout')[0]+'&preflayout=flat')
        ret1.append('0')
        ret1.append('0')
    else:
        ret1=['0','1']
        for i in range(0,l1[2]):
            k=html_splitted[i].find('\"')
            s="http://dl.acm.org/citation.cfm"+html_splitted[i][:k]
            ret.append(s.split('&preflayout')[0]+'&preflayout=flat')
    return ret,ret1
def sorting():
    bigans=[]
    l1=u_filter()
    url="http://dl.acm.org/results.cfm?h=1&query="+'+'.join(l1[0].split())
    fst_l=[]
    ret1=[]
    fst_l,ret1=extract1(url,l1)
    rec(fst_l,l1,bigans)
    if request.args(0)=='0':
        pass
    else:
        bigans=sorted(bigans,key=lambda x:(x[4][6:]*360+x[4][:2]*30+x[4][3:5]),reverse=True)
    au=db(auth.user.username==db.auth_user.username).select().first()
    email=au.email
    return dict(bigans=bigans,level=l1[1],top=l1[2],ret1=ret1,email=email)
def final_ans():
    bigans=[]
    l1=u_filter() 
    url="http://dl.acm.org/results.cfm?h=1&query="+'+'.join(l1[0].split())
    fst_l=[]
    ret1=[]
    fst_l,ret1=extract1(url,l1)
    rec(fst_l,l1,bigans)
    au=db(auth.user.username==db.auth_user.username).select().first()
    email=au.email
    return dict(bigans=bigans,level=l1[1],top=l1[2],ret1=ret1,email=email)
def rec(list1,l1,bigans):
    global count
    count=count+1
    global listf
    listf.append([])
    for x in list1:
        if x!='':
            z=cite(x)
            #global listf
            #listf[count-1].append(z)
            bigans.append(z)
            if count < l1[1]:
                rec(z[7],l1,bigans[-1])
    count=count-1
    return
def cite(url):
    if url=='':
        return []
    l1=u_filter()
    html=fetch(url)
    temp=[]
        #temp=[]
    d=re.search('<meta name="citation_title"[\w\W]*?>',html).group()
    d=bold(d)
        #temp.append(d.split('>')[0][9:-1])
    temp.append(d.split('=')[2][1:-2])
    temp.append(url)
    f=re.search('\"ft_gateway.cfm[\w\W]*?\"',html)
    if f!=None:
        f=f.group()
        f=bold(f)
        temp.append('http://dl.acm.org/'+f[1:-1])
    else:
        temp.append(url)
    c=re.search('<meta name="citation_authors"[\w\W]*?>',html).group()
    c=bold(c)
    if l1[3]==1:
       #temp.append(d.split('>')[0][9:-1])
        temp.append(c.split('=')[2][1:-2])
    else:
        temp.append(-1)
    b=re.search('<meta name="citation_date"[\w\W]*?>',html).group()
    b=bold(b)
    if l1[5]==1:
        temp.append(b.split('=')[2][1:-2])
    else:
        temp.append(-1)
    h=re.search('<A NAME="abstract" class="small-text">ABSTRACT[\w\W]*?</div>',html)
    if h!=None:
        h=h.group()
        h=bold(h)
        if 'An abstract is not available.' in h:
            h1="An abstract is not available."
        elif '<div style=\"display:inline\">' in h:

            h1=h.split('<div style=\"display:inline\">')[1]
            h1=remove(h1)
        else:
            h=h.replace('</A></h1>','')
            h=remove(h)
            h1=h.split('>')[1]
            

        #h.replace("<par>","")
        #h.replace("</par>","")
        #h.replace("<p>","")
        #h.replace("</p>","")
        #h.replace("<p>","")
        #h.replace("</p>","")
        #h1=h.split("</div>")[0]
        #h1=h1.split('<div style="display:inline">')[1]
        #pre=""
        #while pre!=h1:
         #   pre=h1
          #  h1=h1.replace("<br>","")
        #h1=remove(h1)
    else:
        h1=-1
    temp.append(h1)
    s=re.search('CITED BY[\w\W]*?INDEX TERMS',html).group()
    if 'Citings are not available' not in s:
        e=re.search('\d* Citations',s)
        if l1[4]!=1:
            temp.append(-1)
        elif e!=None:
            temp.append(e.group().split()[0])
        else:                                                                            
            temp.append(1)
        i=0
        cit=[]
        while i < l1[2]:
            i+=1
            s1=re.search('<a href[\w\W]*?</a>',s)
            if s1==None:
                cit.append('')
            elif s1!=None:
                k=s.find(s1.group())
                #k1=s[:k]
                cit.append(("http://dl.acm.org/"+s1.group().split('\"')[1]).split('&preflayout')[0]+'&preflayout=flat')
                s=s[k+2:]
           
        temp.append(cit)
    else:
        if l1[4]==1:
            temp.append(0)
        else:
            temp.append(-1)
        temp.append([])
    return temp
def u_filter():
    inpu=db().select(db.input.ALL)
    for inp in inpu:
        key=inp.keywords
        level=inp.Recursion_levels
        top=inp.Top_results
        auth=inp.Show_author
        cited_by=inp.Show_no_of_citations
        year=inp.Show_release_date
    return [key,level,top,auth,cited_by,year]
def bold(d):
    pre=""
    while pre!=d:
        pre=d
        d=d.replace("<b>","")
        d=d.replace("</b>","")
    return d
def remove(d):
    pre=""
    while pre!=d:
        pre=d
        d=d.replace("<p>","")
        d=d.replace("</p>","")
    pre=""
    while pre!=d:
        pre=d
        d=d.replace("<div style=\"display:inline\">","")
        d=d.replace("</div>","")
    pre=""
    while pre!=d:
        pre=d
        d=d.replace("<br>","")
    pre=""
    while pre!=d:
        pre=d
        d=d.replace("<par>","")
        d=d.replace("</par>","")
    return d
def abstract():
    h1=request.args(0)
    h1=XML(h1)
    return dict(abst=h1)
def abstract1():
    abss=request.args[0]
    pre=""
    while pre!=abss:
        pre=abss
        abss=abss.replace("_"," ")
        #d=d.replace("","")
    abss1=abss.split(".")       
    return dict(abss1=abss1)
